#-*- coding: utf-8 -*-
# @Time    : 2019/4/20 23:11
# @Author  : Z
# @Email   : S
# @File    : hbase_test.py
from pysparkDemo.rules.write_hbase import hbase1

hbase={}
hbase["table"]="test_ma"
hbase["families"]=["info"]
hbase["row"]="sale_center_id"

print(hbase)